#!/usr/bin/env bash
#
#   sudo ./uninstall.sh
#   sudo ./uninstall.sh  -y
#
# Reverses install.sh. Every step is existence-checked before it acts, so a
# half-finished or broken install is still cleaned correctly and a piece that
# is already gone reports "skip" instead of failing the run.
set -euo pipefail

# ---- defaults -------------------------------------------------------------
PREFIX=/usr/local/bin
WORKDIR=/etc/phoenix-tunnel
SERVICE=phoenix-tunnel
SYSCTL_CONF=/etc/sysctl.d/99-phoenix-tunnel.conf
# The nft table name is compiled into the server (tun_linux.go: nftTable) and is
# fixed, so it needs no discovery — the whole table goes in one delete.
NFT_TABLE=phoenix_tunnel
# Fallbacks for a unit file that is missing or unreadable. install.sh takes
# --port/--tun/--subnet, so these describe a DEFAULT install only; when the unit
# exists it is the authority, so a non-default install is still cleaned exactly.
PORT=3478
TUN=phoenix0
SUBNET=10.77.0.1/24
# Package-managed netfilter binaries live in /usr/sbin, which a stripped sudo
# PATH can hide — resolve against the full admin path (as install.sh does).
export PATH="$PATH:/usr/sbin:/sbin"

ASSUME_YES=0
DRY_RUN=0
WROTE_HOST=0
ORIG_ARGS="$*"

# ---- helpers --------------------------------------------------------------
c()   { printf '\033[%sm%s\033[0m' "$1" "$2"; }
info(){ echo "$(c '1;36' '==>') $*"; }
ok()  { echo "  $(c '1;32' 'done:') $*"; }
none(){ echo "  $(c '1;90' 'skip:') $*"; }

# Same contract as the installer: every non-fatal issue is recorded, and the run
# ends with one verdict that accounts for all of them. "ALL SUCCESS" is only
# printed when nothing was recorded — for a removal, a warning means something
# was left behind, which is exactly the outcome an operator must not miss.
PROBLEMS=()

finish() { # the single verdict for the whole run; the exit code follows the
           # recorded severity, never the caller's intent.
  local n_err=0 n_warn=0 i=1 line

  for line in "${PROBLEMS[@]+"${PROBLEMS[@]}"}"; do
    case "$line" in
      ERROR:*)   n_err=$((n_err + 1)) ;;
      WARNING:*) n_warn=$((n_warn + 1)) ;;
    esac
  done

  echo
  echo "------------------------------------------------------------"
  if [[ $DRY_RUN -eq 1 ]]; then
    # A dry run changes nothing, so the host is EXPECTED to still be installed.
    # Judging it by the same "is it gone?" standard as a real run would report
    # every untouched file as an error and train the operator to ignore red.
    if [[ $n_err -eq 0 && $n_warn -eq 0 ]]; then
      echo "  $(c '1;36' 'DRY RUN') — plan is clean; nothing was changed."
      echo "------------------------------------------------------------"
      exit 0
    fi
    echo "  $(c '1;33' 'DRY RUN') — $((n_err + n_warn)) issue(s) in the plan: $n_err error(s), $n_warn warning(s)."
    elif [[ $n_err -eq 0 && $n_warn -eq 0 ]]; then
      echo "  $(c '1;32' 'ALL SUCCESS') — removed; nothing of $SERVICE is left on this host."
      if [[ $IMPORT_LINKS -gt 0 ]]; then
        echo "  $(c '1;31' 'Destroyed:') $IMPORT_LINKS import link(s) and the server key — every existing phx1:// link for this server is now dead."
      fi
      echo "------------------------------------------------------------"
      exit 0
  elif [[ $n_err -gt 0 ]]; then
    echo "  $(c '1;31' 'UNINSTALL INCOMPLETE') — $((n_err + n_warn)) problem(s): $n_err error(s), $n_warn warning(s)."
  else
    echo "  $(c '1;33' 'COMPLETED WITH WARNINGS') — $n_warn warning(s), 0 error(s). Something was left behind."
  fi
  echo "------------------------------------------------------------"
  for line in "${PROBLEMS[@]+"${PROBLEMS[@]}"}"; do
    case "$line" in
      ERROR:*)   printf '  %d. %s %s\n'   "$i" "$(c '1;31'   '[ERROR]')"   "${line#ERROR:}" ;;
      WARNING:*) printf '  %d. %s %s\n'   "$i" "$(c '1;33'   '[WARNING]')" "${line#WARNING:}" ;;
      *)         printf '  %d. %s\n'      "$i" "$line" ;;
    esac
    i=$((i + 1))
  done
  echo "------------------------------------------------------------"
  if [[ $WROTE_HOST -eq 1 && $DRY_RUN -eq 0 ]]; then
    echo "  Re-run this script, or finish by hand:"
    echo "    systemctl status $SERVICE"
    echo "    journalctl -u $SERVICE -e | tail -40"
  elif [[ $DRY_RUN -eq 1 ]]; then
    echo "  Nothing was changed. Re-run without --dry-run to apply this plan."
  else
    echo "  Nothing was removed — the host was not modified."
  fi
  echo "------------------------------------------------------------"
  exit 1
}

warn(){ echo "$(c '1;33' 'warning:') $*" >&2; PROBLEMS+=("WARNING: $*"); }
# fail records a fatal problem WITHOUT stopping the run, so the remaining
# cleanup (and the final verdict) still happen — a removal must not abort
# halfway and leave the host in a state neither script fully describes.
fail(){ echo "$(c '1;31' 'error:') $*" >&2; PROBLEMS+=("ERROR: $*"); }
die()  { echo "$(c '1;31' 'error:') $*" >&2; PROBLEMS+=("ERROR: $*"); finish; }

# run <cmd...> — print the command, then execute it; under --dry-run print it and
# stop. Same output either way, so a dry run previews the real run exactly.
run() {
  printf '    $ %s\n' "$(printf '%q ' "$@")"
  if [[ $DRY_RUN -eq 1 ]]; then return 0; fi
  "$@"
}

# removed_note <what> — say honestly whether the removal happened or would have.
removed_note() {
  if [[ $DRY_RUN -eq 1 ]]; then none "would remove: $1"; else ok "$1"; fi
}

usage() {
  cat <<EOF
Phoenix Tunnel uninstaller

Usage: sudo ./uninstall.sh [options]

  --port <n>          port to close (default: read from the installed unit,
                      else $PORT)
  --tun <name>        tun device whose NAT rules to remove (default: from the
                      installed unit, else $TUN)
  --subnet <ip[/pfx]> tunnel subnet whose MASQUERADE rule to remove (default:
                      from the installed unit, else $SUBNET)
  --dry-run           print every action, change nothing
  -y, --yes           do not ask for confirmation
  -h, --help

What it removes — unconditionally, there is no keep option:
  service $SERVICE (stop + disable), $PREFIX/phoenix-tunnel,
  /etc/systemd/system/$SERVICE.service, $WORKDIR (server key + every
  import link), $SYSCTL_CONF, the nft table inet $NFT_TABLE, the iptables
  MASQUERADE/FORWARD rules, and the $PORT/udp firewall hole.

Reinstalling after a removal regenerates a NEW server key, so every existing
import link (phx1://) stops working. That is irreversible — use --dry-run first
if you only want to see the plan.

Examples:
  sudo ./uninstall.sh --dry-run
  sudo ./uninstall.sh
EOF
}

# ---- parse args -----------------------------------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --port)      PORT="$2"; shift 2;;
    --tun)       TUN="$2"; shift 2;;
    --subnet)    SUBNET="$2"; shift 2;;
    --dry-run)   DRY_RUN=1; shift;;
    -y|--yes)    ASSUME_YES=1; shift;;
    -h|--help)   usage; exit 0;;
    *)           die "unknown option: $1 (see --help)";;
  esac
done

if [[ $EUID -ne 0 ]]; then
  echo "$(c '1;31' 'error:') must run as root: sudo $0 $ORIG_ARGS" >&2
  exit 1
fi

# ---- discover how this host was actually installed -------------------------
# The unit file is the authority. install.sh lets the operator change --port,
# --tun and --subnet, and those values are baked into ExecStart; a script that
# assumed defaults would close the wrong firewall port and leave the real NAT
# rule behind. Read them back instead of guessing.
#
# A field that cannot be parsed is a WARNING, never a silent fallback: falling
# back quietly is how the wrong masquerade rule gets deleted while the real one
# survives. The alternative — die — is too harsh, since a hand-edited unit can
# still be cleaned by hand with --port/--tun/--subnet.
UNIT_UNPARSED=()
read_unit_config() {
  local unit="/etc/systemd/system/$SERVICE.service" line val
  [[ -f "$unit" ]] || return 1
  line="$(sed -n 's/^ExecStart=//p' "$unit" | head -1)"
  [[ -n "$line" ]] || return 1

  # The subnet expression needs '|' as the s/// delimiter: its own pattern
  # contains a literal '/' (the CIDR mask), which would terminate a '/'-
  # delimited expression early and leave the field silently unparsed.
  if   val="$(sed -nE 's|.*-port[= ]([0-9]+).*|\1|p'                <<<"$line")" && [[ -n "$val" ]]; then
    PORT="$val"
  elif val="$(sed -nE 's|.*-listen[= ]:?([0-9]+).*|\1|p'            <<<"$line")" && [[ -n "$val" ]]; then
    PORT="$val"
  else
    UNIT_UNPARSED+=("port")
  fi
  if val="$(sed -nE 's|.*-tun[= ]([A-Za-z0-9_.-]+).*|\1|p'          <<<"$line")" && [[ -n "$val" ]]; then
    TUN="$val"
  else
    UNIT_UNPARSED+=("tun")
  fi
  if val="$(sed -nE 's|.*-subnet[= ]([0-9.]+(/[0-9]+)?).*|\1|p'     <<<"$line")" && [[ -n "$val" ]]; then
    SUBNET="$val"
  else
    UNIT_UNPARSED+=("subnet")
  fi
  return 0
}

# normalize_cidr <ip>[/prefix] — the network address the server itself would have
# put in its netfilter rule (it parses the same string with net.ParseCIDR and
# uses subnet.String()). A missing or bad prefix is reported, never guessed: a
# bare host IP means the server refused to start, so no rule can exist for it.
normalize_cidr() {
  local spec="$1" prefix ip o1 o2 o3 o4 mask addr
  [[ "$spec" == */* ]] || return 1
  prefix="${spec##*/}"; ip="${spec%%/*}"
  [[ "$prefix" =~ ^[0-9]{1,2}$ ]] && (( prefix <= 32 )) || return 1
  [[ "$ip" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]] || return 1
  IFS=. read -r o1 o2 o3 o4 <<<"$ip"
  (( o1 <= 255 && o2 <= 255 && o3 <= 255 && o4 <= 255 )) || return 1
  mask=$(( (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF ))
  addr=$(( ((o1 << 24) | (o2 << 16) | (o3 << 8) | o4) & mask ))
  printf '%d.%d.%d.%d/%s\n' \
    $(( (addr >> 24) & 255 )) $(( (addr >> 16) & 255 )) \
    $(( (addr >>  8) & 255 )) $((  addr        & 255 )) "$prefix"
}

# detect_wan — mirror of the server's detectWAN (tun_linux.go): the egress
# device the masquerade rule was written against. Without it the iptables rule
# cannot be reconstructed, because -o is part of the rule identity.
detect_wan() {
  command -v ip >/dev/null 2>&1 || return 1
  ip -o route get 1.1.1.1 2>/dev/null \
    | tr ' ' '\n' | awk 'p { print; exit } $0 == "dev" { p = 1 }'
}

# Anything of ours still on disk / in netfilter? Distinguishes "a partial or
# custom install whose unit file I cannot read" (worth a warning) from "this
# host never had the service" (a normal nothing-to-do). Warning on the latter
# would end in "Something was left behind" on a host with nothing on it, and
# that is how operators learn to ignore the verdict.
install_artifacts_present() {
  if [[ -f "/etc/systemd/system/$SERVICE.service" ]] || [[ -e "$PREFIX/phoenix-tunnel" ]] \
     || [[ -e "$WORKDIR" ]] || [[ -f "$SYSCTL_CONF" ]]; then
    return 0
  fi
  if command -v nft >/dev/null 2>&1 && nft list table inet "$NFT_TABLE" >/dev/null 2>&1; then
    return 0
  fi
  return 1
}

info "reading installed configuration"
if read_unit_config; then
  info "unit file: port=$PORT tun=$TUN subnet=$SUBNET"
  if ((${#UNIT_UNPARSED[@]} > 0)); then
    warn "could not read ${UNIT_UNPARSED[*]} from the unit's ExecStart — using the built-in default(s) instead; re-run with --port/--tun/--subnet to target the real values."
  fi
elif install_artifacts_present; then
  warn "no readable /etc/systemd/system/$SERVICE.service, but other phoenix-tunnel state exists — falling back to defaults (port=$PORT tun=$TUN subnet=$SUBNET); pass --port/--tun/--subnet if this host was installed non-default."
else
  none "phoenix-tunnel does not appear to be installed (no unit, binary, workdir or sysctl drop-in)"
fi
CIDR="$(normalize_cidr "$SUBNET" || true)"
if [[ -z "$CIDR" ]]; then
  warn "subnet '$SUBNET' has no usable /prefix; the server (net.ParseCIDR) would have refused it, so no iptables rule can match it. Only the fixed nft table will be cleaned."
fi

# Count the import links up front. The server writes one import-url-<device>.txt
# per device in multi-device mode (gen_devices.go), plus a plain import-url.txt
# in single-key mode (main.go), all inside the workdir. Each embeds a client
# private key, so the count is shown in the plan, before the confirmation, and
# again in the verdict — deleting a secret is not something to do silently.
IMPORT_LINKS=0
if [[ -d "$WORKDIR" ]]; then
  IMPORT_LINKS="$(find "$WORKDIR" -maxdepth 1 -type f -name 'import-url*.txt' 2>/dev/null | wc -l)"
fi

# ---- confirm --------------------------------------------------------------
echo
echo "  Will remove:"
echo "    service   : $SERVICE (stop + disable)"
echo "    binary    : $PREFIX/phoenix-tunnel"
echo "    unit file : /etc/systemd/system/$SERVICE.service"
echo "    data      : $WORKDIR  $(c '1;31' "(server key + $IMPORT_LINKS import link(s) — IRREVERSIBLE)")"
echo "    sysctl    : $SYSCTL_CONF"
if [[ $IMPORT_LINKS -gt 0 ]]; then
  echo "    $(c '1;31' 'note')       : the $IMPORT_LINKS import link file(s) contain CLIENT PRIVATE KEYS."
  echo "               Reinstalling generates a new server key, so every existing phx1:// link stops working."
fi
echo "    netfilter : ${CIDR:-n/a} masquerade, tun $TUN, nft table inet $NFT_TABLE"
echo "    firewall  : $PORT/udp"

if [[ $ASSUME_YES -ne 1 ]]; then
  reply=""
  read -r -p "  $(c '1;33' 'Proceed?') [y/N] " reply \
    || { echo; info "aborted — nothing was removed."; exit 0; }
  case "$reply" in
    [yY]|[yY][eE][sS]) ;;
    *) echo; info "aborted — nothing was removed."; exit 0;;
  esac
fi
echo

# From here the run mutates the host, so the verdict may point at the service.
WROTE_HOST=1

# ---- 1. stop + disable the service ----------------------------------------
# Stopping first matters: the server holds a deferred cleanupNAT that removes its
# own netfilter rules on a graceful exit. Everything after this point is
# therefore a safety net for a half-finished or force-killed install.
if [[ -f "/etc/systemd/system/$SERVICE.service" ]] || systemctl cat "$SERVICE" >/dev/null 2>&1; then
  info "stopping and disabling $SERVICE"
  run systemctl stop "$SERVICE"            || fail "could not stop $SERVICE"
  run systemctl disable "$SERVICE"         || warn "could not disable $SERVICE (it may already be gone)"
  run systemctl reset-failed "$SERVICE"    || true
  ok "$SERVICE stopped"
else
  none "service $SERVICE is not installed"
fi

# ---- 2. close the firewall hole -------------------------------------------
# Mirrors install.sh's open_firewall_port, which prefers ufw, then firewalld,
# then a raw iptables ACCEPT. The raw rule is removed regardless of which
# wrapper is present now: the wrapper may have been installed or removed since,
# and a leftover INPUT ACCEPT is a silent hole in the host.
close_firewall_port() { # close_firewall_port <proto> <port>
  local proto="$1" port="$2" n=0
  if command -v ufw >/dev/null 2>&1; then
    run ufw delete allow "$port/$proto" >/dev/null || true
  fi
  if command -v firewall-cmd >/dev/null 2>&1; then
    run firewall-cmd --permanent --remove-port="$port/$proto" >/dev/null || true
    run firewall-cmd --reload >/dev/null || true
  fi
  if command -v iptables >/dev/null 2>&1; then
    if [[ $DRY_RUN -eq 1 ]]; then
      # The -C/-D pair must not drive the loop under --dry-run: run() prints the
      # -D without executing it, so -C would keep succeeding forever and the
      # preview would hang. Report the single command instead.
      if iptables -C INPUT -p "$proto" --dport "$port" -j ACCEPT 2>/dev/null; then
        run iptables -D INPUT -p "$proto" --dport "$port" -j ACCEPT >/dev/null
        n=1
      fi
    else
      # -D once per match: the installer only ever adds one, but a repeated
      # install (or manual tinkering) can leave duplicates, and -C/-D pairs walk
      # them all off.
      while iptables -C INPUT -p "$proto" --dport "$port" -j ACCEPT 2>/dev/null; do
        run iptables -D INPUT -p "$proto" --dport "$port" -j ACCEPT >/dev/null || break
        n=$((n + 1))
      done
    fi
  fi
  if [[ $n -gt 0 ]]; then removed_note "$n iptables INPUT ACCEPT rule(s) for $port/$proto"; fi
}
info "closing firewall port $PORT/udp"
close_firewall_port udp "$PORT"

# ---- 3. netfilter: the tunnel's MASQUERADE + FORWARD rules -----------------
clean_nft() {
  command -v nft >/dev/null 2>&1 || return 1
  if nft list table inet "$NFT_TABLE" >/dev/null 2>&1; then
    if run nft delete table inet "$NFT_TABLE"; then
      removed_note "nft table inet $NFT_TABLE (masquerade + forward)"
    else
      fail "could not delete nft table inet $NFT_TABLE"
    fi
  else
    none "nft table inet $NFT_TABLE not present"
  fi
}
clean_iptables() {
  command -v iptables >/dev/null 2>&1 || return 1
  local dev src masq_ours=0
  [[ -n "$CIDR" ]] || { none "no usable subnet — no iptables rule to match"; return 0; }
  dev="$(detect_wan || true)"
  if [[ -z "$dev" ]]; then
    warn "cannot detect the egress interface (ip route get 1.1.1.1) — the masquerade rule is matched on '-o <dev>', so it may be left behind. Remove it by hand: iptables -t nat -D POSTROUTING -s $CIDR -o <dev> -j MASQUERADE"
    return 0
  fi
  src="$CIDR"
  # Ownership is proven BEFORE anything is deleted: the generic
  # ESTABLISHED,RELATED accept below is only ours if the server's own
  # masquerade rule is here, and that rule is the first thing removed.
  if iptables -t nat -C POSTROUTING -s "$src" -o "$dev" -j MASQUERADE 2>/dev/null; then
    masq_ours=1
  fi
  # Rule identities copied from the server's iptablesApply (tun_linux.go) so
  # -C/-D match exactly. Order mirrors its cleanupNAT: POSTROUTING first, to
  # avoid a brief window where FORWARD still relays but the source is unmapped.
  if iptables -t nat -C POSTROUTING -s "$src" -o "$dev" -j MASQUERADE 2>/dev/null; then
    if run iptables -t nat -D POSTROUTING -s "$src" -o "$dev" -j MASQUERADE; then
      removed_note "iptables nat POSTROUTING masquerade for $src via $dev"
    else
      fail "could not delete the nat POSTROUTING masquerade rule"
    fi
  else
    none "iptables nat POSTROUTING masquerade for $src not present"
  fi
  if iptables -C FORWARD -i "$TUN" -j ACCEPT 2>/dev/null; then
    if run iptables -D FORWARD -i "$TUN" -j ACCEPT; then
      removed_note "iptables FORWARD accept for $TUN"
    else
      fail "could not delete the FORWARD accept rule for $TUN"
    fi
  else
    none "iptables FORWARD accept for $TUN not present"
  fi
  # The ESTABLISHED,RELATED accept is a GENERIC rule the server also adds. It is
  # only ours when the masquerade rule above proved the iptables backend ran
  # here; deleting it on a host that had its own would break unrelated routing.
  if [[ $masq_ours -eq 1 ]] && iptables -C FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT 2>/dev/null; then
    if run iptables -D FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT; then
      removed_note "iptables FORWARD established,related accept"
    else
      fail "could not delete the FORWARD established,related accept rule"
    fi
  else
    none "generic FORWARD established,related accept left in place (not provably ours)"
  fi
}
info "removing tunnel netfilter rules"
clean_nft || true
clean_iptables || true

# ---- 4. files --------------------------------------------------------------
remove_path() { # remove_path <path> <label>
  local p="$1" label="$2"
  if [[ -e "$p" || -L "$p" ]]; then
    if run rm -rf "$p"; then removed_note "$label ($p)"; else fail "could not remove $p"; fi
  else
    none "$label ($p) not present"
  fi
}
info "removing installed files"
remove_path "$PREFIX/phoenix-tunnel" "binary"
remove_path "/etc/systemd/system/$SERVICE.service" "systemd unit"
# Counted BEFORE the workdir goes: every import-url*.txt embeds a client
# private key, so the operator gets to see how many live secrets this run
# destroys. Reported even on an absent workdir (0), so the number in the plan
# is always the number acted on.
remove_path "$WORKDIR" "workdir (server key + $IMPORT_LINKS import link(s))"

# ---- 5. sysctl -------------------------------------------------------------
# sysctl --system re-applies every REMAINING /etc/sysctl.d file, so the kernel
# falls back to whatever the rest of the host config says. The values are never
# hand-forced to 0: on a host that routed traffic before the install, 0 would be
# the wrong answer, and this script cannot know that.
if [[ -f "$SYSCTL_CONF" ]]; then
  info "removing $SYSCTL_CONF and reloading sysctl"
  if run rm -f "$SYSCTL_CONF"; then
    if run sysctl --system >/dev/null; then
      removed_note "sysctl drop-in; kernel reloaded from the remaining host config"
    else
      warn "sysctl --system failed after removing $SYSCTL_CONF — re-run 'sysctl --system' by hand"
    fi
  else
    fail "could not remove $SYSCTL_CONF"
  fi
else
  none "$SYSCTL_CONF not present"
fi

info "reloading systemd"
run systemctl daemon-reload || warn "systemctl daemon-reload failed"

# ---- 6. verify -------------------------------------------------------------
# Every claim above is re-read from the host, so the verdict reports the real
# state rather than what the commands were supposed to achieve. Skipped under
# --dry-run: nothing was removed, so nothing could be gone.
if [[ $DRY_RUN -eq 1 ]]; then
  info "dry run — verification skipped (nothing was removed)"
else
echo
info "verifying"
verify_gone() { # verify_gone <description> <test-command...>
  local what="$1"; shift
  if "$@" >/dev/null 2>&1; then
    fail "$what still present"
  else
    ok "$what gone"
  fi
}
verify_gone "service in systemd"  systemctl cat "$SERVICE"
verify_gone "binary $PREFIX/phoenix-tunnel" test -e "$PREFIX/phoenix-tunnel"
verify_gone "unit file"             test -e "/etc/systemd/system/$SERVICE.service"
verify_gone "workdir $WORKDIR" test -e "$WORKDIR"
if [[ $IMPORT_LINKS -gt 0 ]]; then
  if find "$WORKDIR" -maxdepth 1 -type f -name 'import-url*.txt' 2>/dev/null | grep -q .; then
    fail "import link file(s) still present in $WORKDIR"
  else
    ok "all $IMPORT_LINKS import link(s) gone (verified by name)"
  fi
fi
verify_gone "$SYSCTL_CONF" test -f "$SYSCTL_CONF"
if command -v nft >/dev/null 2>&1; then
  verify_gone "nft table inet $NFT_TABLE" nft list table inet "$NFT_TABLE"
fi
if command -v ss >/dev/null 2>&1; then
  # The port must be followed by whitespace, so :1194 matches but :11940 does not.
  if ss -lun 2>/dev/null | grep -qE "[:.]$PORT[[:space:]]"; then
    warn "something still listens on UDP $PORT (check it is not another service): ss -lunp | grep $PORT"
  else
    ok "nothing listening on UDP $PORT"
  fi
fi
fi

finish
